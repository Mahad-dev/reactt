const TableCell = (props) => {
  return <div >{props.getValue()}</div>;
};

export default TableCell;
